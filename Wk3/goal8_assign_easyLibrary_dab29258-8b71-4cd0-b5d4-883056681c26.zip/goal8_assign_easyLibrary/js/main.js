/*
	PWA1: Goal8: Simple Library App
*/

(function(){


})();  // end wrapper